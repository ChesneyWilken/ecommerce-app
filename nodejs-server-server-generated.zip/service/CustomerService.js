'use strict';


/**
 * Returns information about the currently logged in user
 *
 * no response value expected for this operation
 **/
exports.getUser = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get a specific user by their ID
 *
 * id String The id of the order.
 * no response value expected for this operation
 **/
exports.getUserById = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Allows existing users to login to their account
 * Example responses for the existing customer login
 *
 * body Login_body 
 * no response value expected for this operation
 **/
exports.login = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Creates a new user
 * Uses the POST operation to create a new user.
 *
 * body Customer A new customer object (optional)
 * no response value expected for this operation
 **/
exports.signUp = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Updates the currently logged in user
 *
 * no response value expected for this operation
 **/
exports.updateUser = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Returns a list of all users
 * This is for users of the API and only authenticated and authorized logins will be able to see this data.
 *
 * no response value expected for this operation
 **/
exports.users = function() {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

