'use strict';


/**
 * Update Order
 * Uses a PUT operation to update the state of an order with a matching id in the orders.json file.
 *
 * id String The id of the order.
 * no response value expected for this operation
 **/
exports.update_order = function(id) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

