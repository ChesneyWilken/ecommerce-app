'use strict';


/**
 * Post new order data
 * The /neworder path uses a POST operation to add a new order to the orders.json file.
 *
 * body Order A new order object (optional)
 * no response value expected for this operation
 **/
exports.post_order = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

